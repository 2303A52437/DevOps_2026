import React from "react";
import StudentCard from "./StudentCard";

function App() {
  //  Student details stored in parent
  const student = {
    name: "Sai Surya",
    rollNo: "2303A52437",
    marks: 87,
    department:"CSE"
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Student Marks Card</h1>

      {/*  Passing data as props */}
      <StudentCard
        name={student.name}
        rollNo={student.rollNo}
        marks={student.marks}
        department={student.department}
      />
    </div>
  );
}

export default App;
